# Temperature Sensor #

There are two devices,
1. Edge Device - Edison
2. IoT Gateway 

Here, in this example, gateway will read temperature from edge device continuously.
