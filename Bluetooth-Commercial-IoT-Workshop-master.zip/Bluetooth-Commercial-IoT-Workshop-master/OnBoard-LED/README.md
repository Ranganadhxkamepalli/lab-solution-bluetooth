# Onboard LED #

There are two devices,
1. Edge Device - Edison
2. IoT Gateway 

Here, in this example, gateway will send a signal every 10 second to turn on and turn off led consecutively which is connected to edge device on Edison.
