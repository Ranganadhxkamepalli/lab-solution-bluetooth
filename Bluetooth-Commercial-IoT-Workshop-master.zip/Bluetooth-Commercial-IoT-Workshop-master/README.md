# Bluetooth Commercial IoT Workshop module

1. Temperature Sensor 
2. Onboard LED

Follow this blog to setup both the devices, edison and gateway
http://rexstjohn.com/configure-intel-edison-for-bluetooth-le-smart-development/
